package alu;

/**
 * Marius
 * @author Ryan Alu, Saint Francis University
 * Apr 7, 2019
 */

public class VelocimetryTester
{
    public static void main(String[] args)
    {
        Velocimetry run = new Velocimetry();
        run.pinpointGroundControl();
        run.print(run.addTimeComponent(run.averages(run.pixelToMeters(run.triangulate(run.pinpointCenterOfBlob(run.createColorArray(run.downloadPictures(run.createArrayofPictureFileLocations()))))))));
    }
}   

package alu;

/**
 * Marius
 * @author Ryan Alu, Saint Francis University
 * Apr 8, 2019
 */

//Class that organizes pixel information - coordinate position and rgb values.
public class ColorCombo
{
    private int red;
    private int green;
    private int blue;
    private int xPos;
    private int yPos;
    
    public ColorCombo()
    {
        red=0;
        green=0;
        blue=0;
        xPos=0;
        yPos=0;
    }
    
    public ColorCombo(int a, int b, int c, int d, int e)
    {
        red = a;
        green = b;
        blue = c;
        xPos=d;
        yPos=e;
    }
    
    public void setMyRed(int r)
    {
        red = r;
    }
    
    public void setMyGreen(int g)
    {
        green = g;
    }
    
    public void setMyBlue(int b)
    {
        blue = b;
    }
    
    public void setXPosition(int d)
    {
        xPos = d;
    }
    
    public void setYPosition(int e)
    {
        yPos = e;
    }
    
    
    public int getMyRed()
    {
        return red;
    }
    
    public int getMyGreen()
    {
        return green;
    }
    
    public int getMyBlue()
    {
        return blue;
    }
    
    public int getXPosition()
    {
        return xPos;
    }
    
    public int getYPosition()
    {
        return yPos;
    }
}   

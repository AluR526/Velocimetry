package alu;
//IF YOU HAVE QUESTIONS CALL 267-474-8097 NO MATTER WHAT YEAR IT IS! I WILL HELP

/**
 * Marius
 * @author Ryan Alu, Saint Francis University
 * Apr 7, 2019
 */

//import of all the tools needed to analyize a picture.
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;


public class Velocimetry
{
    //Only two global variables. First is a list of all the ground references by pixel (x,y coordinate). The second is the total amount of pictures used.
    private ArrayList<CoordinatePair> groundList;
    private final int originalPictureListSize;
    
    public Velocimetry()
    {
        groundList = new ArrayList<>();
        originalPictureListSize = 1585;
    }
    
    //Takes the name of every picture file and puts it into an array.
    public ArrayList<String> createArrayofPictureFileLocations()
    {
        //MANUAL INPUT - The only difference between the file picture names is the ending number. So that is all we will change when creating the next string. The four int's make up the number of the first picture.
        int thousands = 0;
        int hundreds = 5;
        int tens = 7;
        int ones = 8;
        ArrayList<String> fileLocationList = new ArrayList<String>();
        
        
        for(int i=0; i<10000; i++)
        {
            //MANUAL INPUT - Enter file path without the ending number.
            fileLocationList.add("C:\\Users\\SFU\\Desktop\\Marius Project\\FramebyFrame\\3 Brubaker - Tracer near weir (online-video-cutter.com) (3-14-2019 10-59-42 PM)\\3 Brubaker - Tracer near weir (online-video-cutter.com) "
                + thousands + hundreds + tens + ones + ".jpg");
            
            //MANUAL INPUT - The number below is one number after the number of the final picture.
            if(ones==7 && tens==9 && hundreds==2 && thousands==3)
            {
                break;
            }
            
            ones++;
            if(ones>9)
            {
                tens++;
                ones=0;
                if(tens>9)
                {
                    hundreds++;
                    tens=0;
                    if(hundreds>9)
                    {
                        thousands++;
                        hundreds=0;
                    }
                }
            }
        }
        return fileLocationList;
    }
    
    //Download the pictures as readable picture files in java using the imports. If it tries a file path that is not real it catches and moves on.
    public ArrayList<BufferedImage> downloadPictures(ArrayList<String> z)
    {
        ArrayList<BufferedImage> pictureList = new ArrayList<BufferedImage>();
        
        for(int i=0; i<z.size(); i++)
        {
            File file = new File(z.get(i));

            BufferedImage image = null;

            try
            {
                image = ImageIO.read(file);
                pictureList.add(image);
                
            } 
            catch (IOException e) 
            {
                continue;
            }
        }
        return pictureList;
    }
    
    //Create a list in a list that carries the pixel info
    public ArrayList<ArrayList<ColorCombo>> createColorArray(ArrayList<BufferedImage> y)
    {
        //Creating an array list in an array list. Layered -- Picture,pixel,color-make-up
        //What is a ColorCombo? See the class I made called ColorCombo.java
        ArrayList<ArrayList<ColorCombo>> colorList = new ArrayList<>();
        
        for(int i=0; i<originalPictureListSize; i++)
        {   
            ArrayList<ColorCombo> colorListPictureEntry = new ArrayList<>();
            //Set the frame we want to look at (Look only at certain range of pixels)
            for(int j=76; j<=126; j++)//76 = y; 126-76 = height
            {
                for(int k=103; k<=197; k++)//103 = x; 197-103 = width
                {
                    Color selectedPixelColor = new Color(y.get(i).getRGB(k, j));
                    colorListPictureEntry.add(new ColorCombo(selectedPixelColor.getRed(), selectedPixelColor.getGreen(), selectedPixelColor.getBlue(), k, j));
                }
            }
            colorList.add(colorListPictureEntry);
        }
        
        return colorList;
    }
    
    //Welcome to manual input OVERLOAD. Manually input the ground reference pixel coordinate for every ten frames.
    public void pinpointGroundControl()
    {
        ArrayList<Integer> xList = new ArrayList<>();
        ArrayList<Integer> yList = new ArrayList<>();
        
        xList.add(158);
        yList.add(105);
        
        xList.add(157);
        yList.add(105);
        
        xList.add(157);
        yList.add(105);
        
        xList.add(157);
        yList.add(106);
        
        xList.add(158);
        yList.add(107);
        
        xList.add(158);
        yList.add(107);
        
        xList.add(159);
        yList.add(108);
        
        xList.add(159);
        yList.add(108);
        
        xList.add(160);
        yList.add(107);
        
        xList.add(158);
        yList.add(106);
        
        xList.add(157);
        yList.add(105);
        
        xList.add(156);
        yList.add(105);
        
        xList.add(159);
        yList.add(104);
        
        xList.add(159);
        yList.add(104);
        
        xList.add(159);
        yList.add(104);
        
        xList.add(159);
        yList.add(104);
        
        xList.add(159);
        yList.add(103);
        
        xList.add(160);
        yList.add(104);
        
        xList.add(162);
        yList.add(104);
        
        xList.add(164);
        yList.add(105);
        
        xList.add(165);
        yList.add(106);
        
        xList.add(165);
        yList.add(106);
        
        xList.add(166);
        yList.add(106);
        
        xList.add(167);
        yList.add(106);
        
        xList.add(162);
        yList.add(107);
        
        xList.add(161);
        yList.add(107);
        
        xList.add(161);
        yList.add(107);
        
        xList.add(162);
        yList.add(108);
        
        xList.add(162);
        yList.add(108);
        
        xList.add(162);
        yList.add(108);
        
        xList.add(163);
        yList.add(107);
        
        xList.add(165);
        yList.add(106);
        
        xList.add(166);
        yList.add(106);
        
        xList.add(167);
        yList.add(106);
        
        xList.add(168);
        yList.add(107);
        
        xList.add(168);
        yList.add(107);
        
        xList.add(168);
        yList.add(107);
        
        xList.add(163);
        yList.add(105);
        
        xList.add(162);
        yList.add(105);
        
        xList.add(162);
        yList.add(106);
        
        xList.add(162);
        yList.add(106);
        
        xList.add(164);
        yList.add(106);
        
        xList.add(164);
        yList.add(106);
        
        xList.add(164);
        yList.add(105);
        
        xList.add(164);
        yList.add(108);
        
        xList.add(164);
        yList.add(108);
        
        xList.add(163);
        yList.add(108);
        
        xList.add(162);
        yList.add(108);
        
        xList.add(161);
        yList.add(108);
        
        xList.add(160);
        yList.add(108);
        
        xList.add(159);
        yList.add(108);
        
        xList.add(158);
        yList.add(108);
        
        xList.add(157);
        yList.add(108);
        
        xList.add(157);
        yList.add(108);
        
        xList.add(158);
        yList.add(108);
        
        xList.add(159);
        yList.add(109);
        
        xList.add(159);
        yList.add(110);
        
        xList.add(160);
        yList.add(110);
        
        xList.add(160);
        yList.add(110);
        
        xList.add(161);
        yList.add(110);
        
        xList.add(161);
        yList.add(109);
        
        xList.add(162);
        yList.add(109);
        
        xList.add(161);
        yList.add(109);
        
        xList.add(160);
        yList.add(109);
        
        xList.add(160);
        yList.add(109);
        
        xList.add(159);
        yList.add(109);
        
        xList.add(149);
        yList.add(112);
        
        xList.add(149);
        yList.add(113);
        
        xList.add(149);
        yList.add(114);
        
        xList.add(148);
        yList.add(114);
        
        xList.add(147);
        yList.add(115);
        
        xList.add(146);
        yList.add(114);
        
        xList.add(145);
        yList.add(113);
        
        xList.add(143);
        yList.add(112);
        
        xList.add(142);
        yList.add(112);
        
        xList.add(142);
        yList.add(112);
        
        xList.add(142);
        yList.add(112);
        
        xList.add(142);
        yList.add(112);
        
        xList.add(142);
        yList.add(113);
        
        xList.add(143);
        yList.add(115);
        
        xList.add(143);
        yList.add(115);
        
        xList.add(143);
        yList.add(115);
        
        xList.add(142);
        yList.add(115);
        
        xList.add(141);
        yList.add(115);
        
        xList.add(141);
        yList.add(116);
        
        xList.add(140);
        yList.add(116);
        
        xList.add(140);
        yList.add(115);
        
        xList.add(139);
        yList.add(115);
        
        xList.add(139);
        yList.add(113);
        
        xList.add(138);
        yList.add(112);
        
        xList.add(138);
        yList.add(112);
        
        xList.add(137);
        yList.add(111);
        
        xList.add(136);
        yList.add(110);
        
        xList.add(137);
        yList.add(110);
        
        xList.add(136);
        yList.add(109);
        
        xList.add(137);
        yList.add(109);
        
        xList.add(138);
        yList.add(109);
        
        xList.add(139);
        yList.add(110);
        
        xList.add(138);
        yList.add(110);
        
        xList.add(137);
        yList.add(111);
        
        xList.add(136);
        yList.add(111);
        
        xList.add(136);
        yList.add(112);
        
        xList.add(136);
        yList.add(111);
        
        xList.add(136);
        yList.add(111);
        
        xList.add(137);
        yList.add(111);
        
        xList.add(137);
        yList.add(110);
        
        xList.add(136);
        yList.add(109);
        
        xList.add(133);
        yList.add(106);
        
        xList.add(134);
        yList.add(106);
        
        xList.add(134);
        yList.add(106);
        
        xList.add(134);
        yList.add(106);
        
        xList.add(135);
        yList.add(106);
        
        xList.add(134);
        yList.add(107);
        
        xList.add(133);
        yList.add(108);
        
        xList.add(133);
        yList.add(109);
        
        xList.add(133);
        yList.add(111);
        
        xList.add(133);
        yList.add(111);
        
        xList.add(133);
        yList.add(111);
        
        xList.add(133);
        yList.add(111);
        
        xList.add(132);
        yList.add(110);
        
        xList.add(132);
        yList.add(110);
        
        xList.add(132);
        yList.add(110);
        
        xList.add(132);
        yList.add(111);
        
        xList.add(132);
        yList.add(112);
        
        xList.add(132);
        yList.add(114);
        
        xList.add(130);
        yList.add(113);
        
        xList.add(130);
        yList.add(113);
        
        xList.add(130);
        yList.add(114);
        
        xList.add(130);
        yList.add(114);
        
        xList.add(131);
        yList.add(115);
        
        xList.add(132);
        yList.add(115);
        
        xList.add(133);
        yList.add(115);
        
        xList.add(133);
        yList.add(115);
        
        xList.add(133);
        yList.add(115);
        
        xList.add(132);
        yList.add(115);
        
        xList.add(132);
        yList.add(115);
        
        xList.add(131);
        yList.add(116);
        
        xList.add(130);
        yList.add(116);
        
        xList.add(130);
        yList.add(116);
        
        xList.add(129);
        yList.add(116);
        
        xList.add(129);
        yList.add(116);
        
        xList.add(128);
        yList.add(113);
        
        xList.add(129);
        yList.add(113);
        
        xList.add(128);
        yList.add(112);
        
        xList.add(128);
        yList.add(112);
        
        xList.add(129);
        yList.add(113);
        
        xList.add(130);
        yList.add(114);
        
        xList.add(130);
        yList.add(114);
        
        xList.add(131);
        yList.add(115);
        
        xList.add(131);
        yList.add(115);
        
        xList.add(131);
        yList.add(116);
        
        xList.add(130);
        yList.add(115);
        
        xList.add(130);
        yList.add(115);
        
        xList.add(130);
        yList.add(116);
        
        xList.add(131);
        yList.add(117);
        
        xList.add(132);
        yList.add(118);
        
        xList.add(134);
        yList.add(118);
        
        xList.add(134);
        yList.add(117);
        
        xList.add(135);
        yList.add(116);
        
        for(int i=0; i<xList.size(); i++)
        {
            groundList.add(new CoordinatePair(xList.get(i),yList.get(i)));
        }
    }
    
    //Create an even more specific window to search for the center of the inserted water (called the blob). Then find the center of the blob every ten frames.
    public ArrayList<CoordinatePair> pinpointCenterOfBlob(ArrayList<ArrayList<ColorCombo>> c)
    {
        ArrayList<ArrayList<CoordinatePair>> triangleWindowList = new ArrayList<>();
        for(int i=0; i<originalPictureListSize; i+=10)
        {
            ArrayList<CoordinatePair> triangleWindow = new ArrayList<>();
            
            //Manual input (Create a triangle (three coordinates) for the window that you want to look for the center of the blob.
            int getToThatPointOffTheBankButNotTooCloseToTheWeirX = groundList.get(i/10).getXPosition2()+5;
            int getToThatPointOffTheBankButNotTooCloseToTheWeirY = groundList.get(i/10).getYPosition2()-5;
            int getToThatPointOffTheBankThatsStraightUpX = groundList.get(i/10).getXPosition2()+5+0;
            int getToThatPointOffTheBankThatsStraightUpY = groundList.get(i/10).getYPosition2()-5-24;
            int getToThatPointOffTheBankThatsDiagonalX = groundList.get(i/10).getXPosition2()+5-12;
            int getToThatPointOffTheBankThatsDiagonalY = groundList.get(i/10).getYPosition2()-5-12;
            
            //This is the star probem from high school. Fills out a triangle shape with the point facing the left and captures every pixel in the triangle.
            int counter = getToThatPointOffTheBankThatsStraightUpX;
            for(int y=getToThatPointOffTheBankThatsStraightUpY; y<=getToThatPointOffTheBankThatsDiagonalY; y++)
            {
                for(int x=getToThatPointOffTheBankThatsStraightUpX; x>=counter; x--)
                {
                    triangleWindow.add(new CoordinatePair(x,y));
                }
                counter--;
            }
            
            counter++;
            counter++;
            for(int y=getToThatPointOffTheBankThatsDiagonalY+1; y<=getToThatPointOffTheBankButNotTooCloseToTheWeirY; y++)
            {
                for(int x=counter; x<=getToThatPointOffTheBankButNotTooCloseToTheWeirX; x++)
                {
                    triangleWindow.add(new CoordinatePair(x,y));
                }
                counter++;
            }
            triangleWindowList.add(triangleWindow);
        }    
        
        
        //Find center of the blob   
        int triangleCounter = -1;
        int totalWeight = 0;
        int weightTimesPositionX = 0;
        int weightTimesPositionY = 0;
        boolean blobInTriangleFound = false;
        ArrayList<CoordinatePair> blobPinPoint = new ArrayList<>();

        for(int b=0; b<originalPictureListSize; b+=10)
        {
            triangleCounter++;
            for(int f=0; f<c.get(b).size(); f++)
            {
                for(int w=0; w<triangleWindowList.get(triangleCounter).size(); w++)
                {
                    if(c.get(b).get(f).getXPosition() == triangleWindowList.get(triangleCounter).get(w).getXPosition2() && c.get(b).get(f).getYPosition() == triangleWindowList.get(triangleCounter).get(w).getYPosition2())//If the pixel is in the triangle window...
                    {
                        if(((c.get(b).get(f).getMyRed()) + (c.get(b).get(f).getMyBlue()) + (c.get(b).get(f).getMyGreen()) >= 630))//If the pixel's RGB value is above 630 (r+g+b) (total weight)(middlePos) = weight(pos) + weight(pos);;; MANUAL INPUT - 630 is the number of the red, green, and blue rgb values added together.
                        {
                            blobInTriangleFound = true;
                            totalWeight += ((c.get(b).get(f).getMyRed()) + (c.get(b).get(f).getMyBlue()) + (c.get(b).get(f).getMyGreen()));
                            weightTimesPositionX += (((c.get(b).get(f).getMyRed()) + (c.get(b).get(f).getMyBlue()) + (c.get(b).get(f).getMyGreen())) * c.get(b).get(f).getXPosition());
                            weightTimesPositionY += (((c.get(b).get(f).getMyRed()) + (c.get(b).get(f).getMyBlue()) + (c.get(b).get(f).getMyGreen())) * c.get(b).get(f).getYPosition());
                        }
                    }
                }
            }
            if(blobInTriangleFound)
            {
                blobPinPoint.add(new CoordinatePair((weightTimesPositionX/totalWeight), (weightTimesPositionY/totalWeight))); //Center of mass formula used.
            }
            else
            {
                blobPinPoint.add(new CoordinatePair(0,0));
            }
            blobInTriangleFound = false;
        }
        return blobPinPoint;
    }
    
    //You have a point (The center of the blob every frame) and the line (the line you do not want to look for the blob anymore (down stream). We want to measure the length of the perpendicular path from the point to the line.
    public ArrayList<Double> triangulate(ArrayList<CoordinatePair> blob)
    {
        double bGround;
        double bBlob;
        double intersectionX;
        double intersectionY;
        ArrayList<Double> pixelLength = new ArrayList<>();
        for(int i=0; i<originalPictureListSize; i+=10)//(int i=20; i<30; i+=10)
        {
            if((blob.get(i/10).getXPosition2()==0) && (blob.get(i/10).getXPosition2()==0))
            {
                pixelLength.add(-99999.0);
            }
            
            else
            {
                bGround = (-1*groundList.get(i/10).getYPosition2()) + groundList.get(i/10).getXPosition2();
                bBlob = (-1*blob.get(i/10).getYPosition2()) - blob.get(i/10).getXPosition2();
                                
                intersectionX = (bGround + (bBlob*-1))/2;
                intersectionY = (intersectionX + bBlob);
                
                pixelLength.add(Math.sqrt(    (Math.pow(   (intersectionX - blob.get(i/10).getXPosition2())  ,2) + Math.pow(   (intersectionY - (-1*blob.get(i/10).getYPosition2())) ,2)    )));
            }
        }
        return pixelLength;
    }
    
    //Convert pixels to meters
    public ArrayList<Double> pixelToMeters(ArrayList<Double> lp)
    {
        ArrayList<Double> lengthMeters = new ArrayList<>();
        //MANUAL INPUT - Below is the pythagorean theorem to find the length (amount of diagonals of a pixel square) of the reference meter stick. Below is 15 over and 17 up from one end of the stick to the other end.
        double meter = (Math.sqrt(Math.pow(15,2)+Math.pow(17,2)));
        
        for(int i=0; i<lp.size(); i++)
        {
            if(lp.get(i) == -99999.0)
            {
                lengthMeters.add(-99999.0);
            }
            else
            {
                lengthMeters.add(lp.get(i) / meter);
            }
        }
        return lengthMeters;
    } 
    
    //Triple array list. OuterList called the carrier. Carrier spot 0 carries a list how far blob traveled betweens frames. Carrier spot 1 carries "list" (each list contains one entry) of how far blob traveled from beginning to end of pour.
    public ArrayList<ArrayList<ArrayList<Double>>> averages(ArrayList<Double> corctd)
    {
        ArrayList<ArrayList<ArrayList<Double>>> carrier = new ArrayList<>();
        ArrayList<ArrayList<Double>> instList = new ArrayList<>();
        ArrayList<ArrayList<Double>> genList = new ArrayList<>();
        carrier.add(instList);
        carrier.add(genList);
        
        int counter = -1;
        for(int i=0; i<corctd.size(); i++)
        {
            if(corctd.get(i) == -99999.0)//Found first frame of no pour
            {
                counter++;
                instList.add(new ArrayList<>());
                while(i != (originalPictureListSize/10) && corctd.get(i+1) == -99999.0)//Speed up until find last frame of no pour (or exit if on last frame of entire video)
                {
                    i++;
                }
            }
            else
            {
                if(corctd.get(i+1) != -99999.0)
                {
                    instList.get(counter).add(corctd.get(i)-corctd.get(i+1)); //Record the difference
                }
            }
        }
        
        counter = -1;
        double beginning=0;
        double ending=0;
        double beg=0;
        double end=0;
        for(int i=0; i<corctd.size(); i++)
        {
            if(corctd.get(i) == -99999.0)//Found first frame of no pour
            {
                counter++;
                genList.add(new ArrayList<>());
                while(i!=(originalPictureListSize/10) && corctd.get(i+1) == -99999.0)//Speed up until find last frame of no pour (or exit if on last frame of entire video)
                {
                    i++;
                }
                if(i==157)
                {
                    break;
                }
            }
            else
            {
                beginning = corctd.get(i);
                beg = i;
                while(corctd.get(i+1) != -99999.0)
                {
                    i++;
                }
                ending = corctd.get(i);
                end = i;
                
                genList.get(counter).add(beginning-ending);
                genList.get(counter).add(end-beg);
            }
        }
        return carrier;
    }
    
    //Convert length to length per second
    public ArrayList<ArrayList<ArrayList<Double>>> addTimeComponent(ArrayList<ArrayList<ArrayList<Double>>> car)
    {
        for(int i=0; i<car.get(0).size(); i++)
        {
            for(int j=0; j<car.get(0).get(i).size()-1; j++)
            {
                car.get(0).get(i).set(j, car.get(0).get(i).get(j)*(10/29.97));
            }
        }
        for(int i=0; i<car.get(1).size()-1; i++)
        {
            car.get(1).get(i).set(0, car.get(1).get(i).get(0)*(car.get(1).get(i).get(1)/29.97));
        }
        
        return car;
    }
    
    //Print the results
    public void print(ArrayList<ArrayList<ArrayList<Double>>> fin)
    {
        System.out.println("Instantaneous Velocities (meters/second)");
        for(int i=0; i<fin.get(0).size()-1; i++)
        {
            System.out.println("POUR " + i);
            for(int j=0; j<fin.get(0).get(i).size(); j++)
            {
                System.out.println(fin.get(0).get(i).get(j));
            }
        }
        System.out.println();
        System.out.println("Average Velocities (meters/second)");
        for(int i=0; i<fin.get(1).size()-1; i++)
        {
            System.out.println("POUR " + i);
            System.out.println(fin.get(1).get(i).get(0));
        }
    }
}   

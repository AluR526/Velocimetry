package alu;

/**
 * Marius
 * @author Ryan Alu, Saint Francis University
 * Apr 8, 2019
 */

public class CoordinatePair
{
    private int xPos;
    private int yPos;
    
    public CoordinatePair()
    {
        xPos=0;
        yPos=0;
    }
    
    public CoordinatePair(int a, int b)
    {
        xPos=a;
        yPos=b;
    }
    
    public void setXPosition2(int d)
    {
        xPos = d;
    }
    
    public void setYPosition2(int e)
    {
        yPos = e;
    }
    
    
    public int getXPosition2()
    {
        return xPos;
    }
    
    public int getYPosition2()
    {
        return yPos;
    }
}   
